"""
CTkRangeSlider
Range slider for customtkinter
Author: Akash Bora
"""

__version__ = '0.2'

from .ctk_rangeslider import CTkRangeSlider
